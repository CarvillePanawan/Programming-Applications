package com.MavenGrp;

import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class TankTruckTest {
    
    @Test
    public void test0() {  
        assertEquals(2940, AllCodes.tankVol(5, 7, 3848));
        assertEquals(907, AllCodes.tankVol(2, 7, 3848));
    }
    
    @Test
    public void test1() {  
        assertEquals(1021, AllCodes.tankVol(40,120,3500));
    }
    
    @Test
    public void test2() {  
        assertEquals(1750, AllCodes.tankVol(60,120,3500));
    }
    
    @Test
    public void test3() {  
        assertEquals(2478, AllCodes.tankVol(80,120,3500));
    }
}
