package com.MavenGrp;

import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class BitCountingTest {
	
		@Test
		public void test0(){
		 assertEquals(5, AllCodes.countBits(1234)); 
    	 assertEquals(1, AllCodes.countBits(4)); 
    	 assertEquals(3, AllCodes.countBits(7)); 
   		 assertEquals(2, AllCodes.countBits(9)); 
   		 assertEquals(2, AllCodes.countBits(10)); 
		}
		
		@Test
		public void test1(){
		 assertEquals(4, AllCodes.countBits(15)); 	
		}
		
		
		@Test
		public void test2(){
		assertEquals(2, AllCodes.countBits(3)); 
		}
		
		@Test
		public void test3(){
		assertEquals(2, AllCodes.countBits(6)); 
		}
		
}