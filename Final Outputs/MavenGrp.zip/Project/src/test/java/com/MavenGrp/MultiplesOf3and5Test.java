package com.MavenGrp;

import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class MultiplesOf3and5Test {
    @Test
    public void test1() {
      assertEquals(23, AllCodes.solution(10));
    }
    @Test
    public void test2() {
      assertEquals(225, AllCodes.solution(33));
    }
    @Test
    public void test3() {
      assertEquals(0, AllCodes.solution(2));
    }
    @Test
    public void test4() {
      assertEquals(2418, AllCodes.solution(101));
    }
    
    
    
}