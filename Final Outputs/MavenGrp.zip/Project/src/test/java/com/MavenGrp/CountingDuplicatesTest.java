package com.MavenGrp;

import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class CountingDuplicatesTest {

   @Test
    public void abcdeReturnsZero() {
        assertEquals(0, AllCodes.duplicateCount("abcde"));
    }
    
    @Test
    public void abcdeaReturnsOne() {
        assertEquals(1, AllCodes.duplicateCount("abcdea"));
    }
    
    @Test
    public void indivisibilityReturnsOne() {
        assertEquals(1, AllCodes.duplicateCount("indivisibility"));
    }
     @Test
    public void emptyReturnsZero() {
        assertEquals(0, AllCodes.duplicateCount("empty"));
    }
    @Test
    public void abcdefghijklmnopqrstuvwxyzReturnsZero() {
        assertEquals(0, AllCodes.duplicateCount("abcdefghijklmnopqrstuvwxyz"));
    }
    
    
}