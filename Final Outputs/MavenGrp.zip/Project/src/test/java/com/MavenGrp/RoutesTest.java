package com.MavenGrp;


import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class RoutesTest {
	@Test
	public void test11() {
		String[][] one = {{"HQ", "SH"}};
		assertEquals("HQ, SH", AllCodes.findRoutes(one));
	}
	@Test
	public void test12() {
		String[][] two = {{"UK", "GER"}, {"GER", "BEL"}, {"BEL", "CAN"}};
		assertEquals("UK, GER, BEL, CAN", AllCodes.findRoutes(two));
	}
	@Test
	public void test13() {
		String[][] three = {{"Chicago", "Winnipeg"}, {"Halifax", "Montreal"}, {"Montreal", "Toronto"}, {"Toronto", "Chicago"}, {"Winnipeg", "Seattle"}};
		assertEquals("Halifax, Montreal, Toronto, Chicago, Winnipeg, Seattle", AllCodes.findRoutes(three));
	}
	@Test
	public void test14() {
		String[][] four = {{"MNL", "TAG"}, {"CEB", "TAC"}, {"TAG", "CEB"}, {"TAC", "BOR"}};
		assertEquals("MNL, TAG, CEB, TAC, BOR", AllCodes.findRoutes(four));
	}
	@Test
	public void test15() {
		String[][] five = {{"BRA", "KSA"}, {"USA", "BRA"}, {"JPN", "PHL"}, {"KSA", "UAE"}, {"UAE", "JPN"}};
		assertEquals("USA, BRA, KSA, UAE, JPN, PHL", AllCodes.findRoutes(five));
	}
	@Test
	public void test16() {
		String[][] six = {{"PHL", "JPN"}, {"SIN", "PHL"}};
		assertEquals("SIN, PHL, JPN", AllCodes.findRoutes(six));
	}
}