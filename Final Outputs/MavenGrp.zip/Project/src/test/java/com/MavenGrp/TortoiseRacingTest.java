package com.MavenGrp;

import org.junit.Test;
import static org.junit.Assert.*;
import java.util.*;

public class TortoiseRacingTest{
	
		@Test
		public void test0(){
		 assertArrayEquals(new int[]{0, 32, 18}, AllCodes.race(720, 850, 70));
		}
		
		@Test
		public void test1(){
		 assertArrayEquals(new int[]{3, 21, 49}, AllCodes.race(80, 91, 37));
		}
		
		
		@Test
		public void test2(){
		assertArrayEquals(new int[]{2, 0, 0}, AllCodes.race(80, 100, 40));
		}

		@Test
		public void test3(){
		 assertArrayEquals((null), AllCodes.race(100,50,40));
		}
	
}