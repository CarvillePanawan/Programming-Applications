package com.MavenGrp;
import org.junit.Test;
import static org.junit.Assert.assertEquals;
import java.util.Arrays;

public class toSmallestTest {

    public static void testing(long n, String res) {
        assertEquals(res, Arrays.toString(AllCodes.smallest(n)));
    }
    @Test
    public void test() {
        testing(261235, "[126235, 2, 0]");
        testing(209917, "[29917, 0, 1]");
        testing(285365, "[238565, 3, 1]");
        testing(269045, "[26945, 3, 0]");
        testing(296837, "[239687, 4, 1]");
    }
}